const json = require('json-loader!./file.json');

import { checkForName } from './js/nameChecker'
import { handleSubmit } from './js/formHandler'
import {functionName} from './js/nameChecker'

console.log(checkForName);

alert("I exsit")